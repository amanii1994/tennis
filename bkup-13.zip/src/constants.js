import React, { Component } from 'react';
const Constants = {
    WITHOUT_AUTH_API_URL: 'http://pydaro.impelreport.com/tennis/api/?process=auth&task=',
    API_URL: 'https://cdlcmobileapps.com/despo/api/?',
    IMAGE_URL: 'https://cdlcmobileapps.com/despo/api/upload/',
    CASE_IMAGE_URL: 'https://cdlcmobileapps.com/admin/uploads/'
}
export default Constants;